#ifndef __LED_H
#define __LED_H

void led_init(void);


//led1
void led1_on(void);
void led1_off(void);


//led2
void led2_on(void);
void led2_off(void);


//led3
void led3_on(void);
void led3_off(void);


//led4
void led4_on(void);
void led4_off(void);

#endif
