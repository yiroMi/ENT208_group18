#ifndef __FIRE_H
#define __FIRE_H

void fire_init(void);
int8_t get_fire(void);

#endif

