#ifndef __SERVO_H
#define __SERVO_H



void Servo_Init(void);


void pwm_setcompare1(uint16_t compare);
void pwm_setcompare2(uint16_t compare);
void pwm_setcompare3(uint16_t compare);
void pwm_setcompare4(uint16_t compare);



void servo_setangle1(float angle);
void servo_setangle2(float angle);
void servo_setangle3(float angle);
void servo_setangle4(float angle);



void servo_1(void);
void servo_2(void);
void servo_3(void);
void servo_4(void);
#endif







