#ifndef __BUZZER_H
#define __BUZZER_H


void buzzer_init(void);
void buzzer_play(void);
void buzzer_stop(void);






#endif


