#include "stm32f10x.h"      // STM32 standard peripheral library
#include "Delay.h"          // Delay functions
#include "led.h"            // LED control
#include "servo.h"          // Servo control (PWM integrated internally)
#include "key.h"            // Key/button module
#include "usart.h"          // USART communication (for voice module)
#include "fire.h"           // Flame detection
#include "buzzer.h"         // Buzzer control

// ================= Global Variables =================

// Key input value (1~4)
uint8_t key_val = 0;

// Selected trash bin ID (1~4)
uint8_t waste_val = 0;

// Flame detection flag (0 = no fire, 1 = fire detected)
int8_t fire = 0;


// ================= Main Function =================
int main()
{
    // ---------- Hardware Initialization ----------

    led_init();         // Initialize LEDs (used for overflow indication)
    Servo_Init();       // Initialize servos (PWM configured internally)
    key_init();         // Initialize keys/buttons
    buzzer_init();      // Initialize buzzer

    Usart2_Init(9600);  // Initialize USART2 (voice module)

    // ---------- Servo Initial Position ----------
    // Reset all trash bins to the closed position
    servo_setangle1(90);
    servo_setangle2(90);
    servo_setangle3(90);
    servo_setangle4(90);


    // ================= Main Loop =================
    while(1)
    {
        // ---------- 1. Overflow Detection ----------
        // Detect whether the trash bin is full
        // If full → LED will be turned on internally
        Overflow();


        // ---------- 2. Voice Control ----------
        // Receive voice command (e.g., "bottle")
        // Convert it into a bin ID → waste_val
        voice_function();


        // ---------- 3. Key Control ----------
        // Read key input (1~4)
        key_val = key_getnum();

        // Map key input to trash bin ID
        if(key_val == 1)
        {
            waste_val = 1;
        }
        else if(key_val == 2)
        {
            waste_val = 2;
        }
        else if(key_val == 3)
        {
            waste_val = 3;
        }
        else if(key_val == 4)
        {
            waste_val = 4;
        }


        // ---------- 4. Flame Detection + Alarm ----------
        // Check if fire is detected
        fire = get_fire();

        if(fire != 0)
        {
            buzzer_play();   // Fire detected → activate buzzer
        }
        else
        {
            buzzer_stop();   // No fire → stop buzzer
        }


        // ---------- 5. Trash Bin Control ----------
        // Open the corresponding bin based on waste_val
        switch(waste_val)
        {
            case 1:
                servo_1();     // Open bin 1
                waste_val = 0; // Reset to avoid repeated execution
                break;

            case 2:
                servo_2();     // Open bin 2
                waste_val = 0;
                break;

            case 3:
                servo_3();     // Open bin 3
                waste_val = 0;
                break;

            case 4:
                servo_4();     // Open bin 4
                waste_val = 0;
                break;

            default:
                break;   // Do nothing if no valid input
        }


        // ---------- 6. Loop Delay ----------
        // Reduce CPU usage and stabilize the system
        Delay_ms(100);
    }
}